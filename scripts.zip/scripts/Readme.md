<!-- mpv_vis - Readme.md -->
<!-- last modified (utc): 2026-11-10-11-08-49 -->
<!-- instructions: on modify, update string. -->

## Visualizers for mpv without text in the middle

v 2026-11-10-1

It displays visualizers when there is no video played, without text in the middle.

### Installing:

copy lua files to mpv/scripts folder, or %appdata%/mpv/scripts, or .cache/mpv/scripts

- visualizer.lua - various audio visualization.

- firequalizer15.lua - linear phase 15-bands equalizer (this is not graphic, it is automatically used)

### Key bindings

use c key to flip through visualizers (the name is shown on screen for 2 seconds)

use standard f key to go to fullscreen in mpv.

firequalizer15.lua: ctrl+e toggles the gain control; UP/DOWN select a band; LEFT/RIGHT change its gain; [ and ] copy the gain of the previous/next band. The ~~/lua-settings folder must exist to save gain values.

### Options (visualizer.lua)

Put them in script-opts/visualizer.conf (one `name=value` per line), or pass them as `--script-opts=visualizer-name=value`.

| option | default | values |
|---|---|---|
| mode | novideo | off, noalbumart, novideo, force |
| name | spectrum | spectrum, showcqtbar, showcqt, showspectrum, showwaves, avectorscope, showvolume, off |
| quality | low | verylow, low, medium, high, veryhigh |
| switch_fixed_fps | 25 | 0 = fps of the quality, 1 and more = override fps |
| switch_columns_height | 6 | 4 to 12; height = visualizer width × value / 16 |
| forcewindow | true | false = do not run when force-window is no |

Options of the spectrum visualizer:

| option | default | values |
|---|---|---|
| switch_column_count | 0 | 0 = use column width; positive = column count and overrides width |
| switch_column_width | 16 | used when count is 0; 0 = native, positive = width in pixels |
| switch_lines | true | draw lines when column count or width is positive |
| switch_hats_decay | 0.95 | 0 = no hats; up to 1 = per-frame decay, closer to 1 falls slower |
| switch_low_cpu_hats | true | compute hats at column width when count or width is positive |
| switch_hats_height | 2 | 1 to 20, caps thickness |
| switch_hats_grow | up | up or down, direction in which thicker caps grow |
| switch_hats_vscale | 1 | 1 to 8, caps computed at 1/N height; cheaper, thicker and move in steps of N pixels |
| switch_display_hats_on_top_of_columns | false | true = also show hats attached to column tops |
| switch_flying_hats_color_same_as_top_of_the_columns | true | true = gradient at hat height; false = orange |
| switch_use_yuv444p | 1 | 0 = yuv420p; 1 = yuv444p for enabled hats of height 1; 2 = always yuv444p |

### visualizer.lua, what was modified:

- removed two lines:  
"axisfile       = data\\\\:'" .. axis_0 .. "':" ..  
"axisfile       = data\\\\:'" .. axis_1 .. "':" ..

- changed font color, in both places:  
"fontcolor      = 'st(0, (midi(f)-53.5)/12); st(1, 0.5 - 0.5 * cos(PI*ld(0))); r(1-ld(1)) + b(ld(1))':" ..  
to  
"fontcolor      = 'a(0)':" ..

- added the spectrum visualizer (the default): bars with a green to red gradient, optional falling caps (hats) and optional lines between columns. It uses native lavfi filters in yuv420p or yuv444p, with constant layers generated once and looped.

- added the options listed above, and an on-screen message with the visualizer name when flipping with the c key.
