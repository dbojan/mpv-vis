# MPV Visualizer Project - spec.md

last modified (utc): 2026-11-10-11-08-49

## 1. Purpose

Provide mpv Lua scripts that render audio visualizations without text in the middle of
the screen, plus a linear-phase 15-band equalizer filter that is applied automatically
to the visualized audio.

Distribution form: plain Lua scripts copied into an mpv `scripts` folder
(`mpv/scripts`, `%appdata%/mpv/scripts`, or `.cache/mpv/scripts`).

Source files in this project folder (current state):

- `visualizer.lua` - audio visualization and visualizer cycling.
- `firequalizer15.lua` - 15-band equalizer UI and firequalizer lavfi filter.
- `Readme.md` - install notes, key bindings, option tables and summary of modifications.
- `rules.md` - working rules for AI reading, writing and coding in this project.
- `todo.txt` - free-form todo notes.
- `vlc-vis-spectrum.png` - screenshot of a VLC bar spectrum (look reference).
- `UNLICENSE`, `_create_backup.sh` - project support files.
- `not_needed_after_editing/` - backup copies kept after verified edits.

There is no build step; mpv loads the scripts directly. Project folder is not assumed
to be a Git worktree.

## 2. visualizer.lua

### 2.1 Options

Defined in the `opts` table and read with `mp.options.read_options(opts, nil, visualizer_hook)`
(config file `script-opts/visualizer.conf`, or `--script-opts=visualizer-<option>=<value>`).

- `mode` (default `"novideo"`):
  - `off` - disable visualization.
  - `noalbumart` - visualize only when there is no album art and no video.
  - `novideo` - visualize when there is no video (album art counts as non-video).
  - `force` - always visualize.
- `name` (default `"spectrum"`): one of `spectrum`, `off`, `showcqt`, `avectorscope`,
  `showspectrum`, `showcqtbar`, `showwaves`, `showvolume`.
- `quality` (default `"low"`): `verylow`, `low`, `medium`, `high`, `veryhigh`.
- `switch_fixed_fps` (default `25`): `0` uses the fps of the quality mapping (2.5);
  `>= 1` overrides it (value floored).
- `switch_columns_height` (default `6`, range 4..12): visualizer height factor; after reading,
  clamped to `[4, 12]` and floored.
- `forcewindow` (default `true`): when false, the script returns early if mpv's
  `force-window` property is `"no"`.

Options used by `spectrum` only:

- `switch_column_count` (default `0`): a positive, floored count overrides column width;
  `0` uses `switch_column_width`.
- `switch_column_width` (default `16`): when count is zero, `0` uses native width
  (`cols = w`); a positive width gives `max(1, floor(w / width))` columns.
- `switch_lines` (default `true`): draw separators when count or width is positive.
- `switch_hats_decay` (default `0.95`): clamped to `[0, 1]`; `0` disables hats.
- `switch_low_cpu_hats` (default `true`): compute hats at column width when count or
  width is positive; otherwise use output width.
- `switch_hats_height` (default `2`): hat thickness, floored and clamped to `[1, 20]`.
- `switch_hats_grow` (default `"up"`): `up` or `down`; invalid values fall back to `up`
  and log an error when hats are enabled.
- `switch_hats_vscale` (default `1`): floored and clamped to `[1, 8]`; hats are computed
  at `1/N` height (at least two rows) and scaled back up.
- `switch_display_hats_on_top_of_columns` (default `false`): include hats attached to
  column tops when true; falling hats are still shown when false.
- `switch_flying_hats_color_same_as_top_of_the_columns` (default `true`): use the gradient
  at each hat's current height; false uses orange. This also affects attached hats.
- `switch_use_yuv444p` (default `1`): `0` uses `yuv420p`; `1` uses `yuv444p` when hats
  are enabled and their configured thickness is 1; `2` always uses `yuv444p` for spectrum.
  Other values use `yuv420p`.

Key binding variables: `cycle_key = "c"`, `osd_format = "Visualizer: %s"`, `osd_time = 2`
(seconds).

### 2.2 Early exit

If mpv property `options/lavfi-complex` is non-empty at script load, the script returns
immediately and does nothing.

### 2.3 Visualizer name list

`visualizer_name_list = { "spectrum", "showcqtbar", "showcqt", "showspectrum",
"showwaves", "avectorscope", "showvolume", "off" }` - used by cycling.

### 2.4 Axis images

`axis_0` and `axis_1` hold large base64 PNG data URIs. They are unused by the current
filter graphs; `Readme.md` records that the `axisfile` lines referencing them were
removed to avoid text in the middle of the display.

### 2.5 Quality mapping

In `get_visualizer(name, quality, vtrack)`:

- `verylow` -> width 640, fps 30
- `low` -> width 960, fps 30
- `medium` -> width 1280, fps 60
- `high` -> width 1920, fps 60
- `veryhigh` -> width 2560, fps 60
- anything else -> log error, return `""`.

If `floor(switch_fixed_fps)` is greater than 0 it replaces `fps` for every quality.

Height is `h = w * opts.switch_columns_height / 16` for all visualizers.

### 2.6 Filter graphs

All graphs start from `[aid1] asplit [ao]` (audio path preserved) and end in a video
output mapped as `[vo]`. `vtrack` is accepted by `get_visualizer` but not used by it;
`off` scans `track-list` itself.

- `spectrum` (default), built from native lavfi filters in `yuv420p` or `yuv444p`:
  - Derived values: `colw = floor(switch_column_width)`; a positive floored
    `switch_column_count` overrides width; otherwise `cols = w` when `colw <= 0`, else
    `max(1, floor(w / colw))`. Lines and low-CPU hats require count or width above zero.
    `hi = floor(h)`; hats are enabled when clamped decay is above zero. Pixel format is
    selected by `switch_use_yuv444p` as described above.
  - Source: `aformat=channel_layouts=stereo`, `showfreqs` (`size=colsxh`, `mode=bar`,
    `rate=fps`, `ascale=log`, `fscale=log`, `win_func=hann`, `colors=white|white`),
    `format=gray`, `lutyuv y='if(gt(val,16),255,0)'` -> `[m0]` (binary mask).
  - `yuv_mask(src, dst)` scales gray masks with nearest-neighbor and copies the mask
    into every plane: full size for `yuv444p`, or full-size Y and half-size U/V for
    `yuv420p`, using `mergeplanes=0x001020`.
  - Cached layers: the string `,trim=end_frame=1,loop=loop=-1:size=1` is appended to
    constant sources so each is generated once and looped: gradient `[grad]`, black
    background `[bg]`, orange `[hatcolor]` (when hats use orange), white grid layer `[gl]` (lines only) and
    the hats threshold ramp `[ramp]` (hats only).
  - Gradient: `color` `1xhi` in `rgb24` with `geq` (`t = (H-1-Y)/(H-1)`;
    `r = if(t<0.6, 255*t/0.6, 255)`, `g = if(t<0.6, 255, if(t<0.9, 255*(1-(t-0.6)/0.3), 0))`,
    `b = 0`), `scale=w:hi:flags=bilinear`, then the selected YUV format.
  - Bars: `[bg][grad][mask]maskedmerge`, where `[mask]` is `yuv_mask` of the bar mask.
  - Hats (when enabled): `[m0]` is split into the bar mask and the hats source. The hats
    source is scaled with `flags=neighbor` to `hat_w x hat_h` (`hat_w = cols` when
    `low_cpu`, else `w`; `hat_h = hi`, or `max(2, floor(hi / switch_hats_vscale))` when the
    vscale is above 1) or passed through `null` when no scaling is needed. It is split
    into `hcur1` and `hdrop`, plus `hcur2` when attached hats are enabled:
    - `hcur1` -> `lagfun=decay=<decay>` -> `hlag`, split in `hlag1` and `hlag2`.
    - `[ramp]`: `color` `hat_w x hat_h` `gray` with `geq lum='floor(254*(1-Y/(H-1)))'`.
    - `hthr = [hlag1][ramp]blend=all_mode=subtract` then `lutyuv y='if(gt(val,0),255,0)'`.
    - Edge of a mask = mask minus the mask eroded from above: `erosion=coordinates=2`
      applied `edge_steps` times, then `blend=all_mode=subtract`. `edge_steps` is
      `switch_hats_height` for `down`, otherwise 1.
    - `hfall` = edge of `hthr`; `hdiff = [hlag2][hdrop]blend=all_mode=difference`;
      `hfall2 = [hfall][hdiff]blend=all_mode=multiply`; when enabled, `hcur` = edge of `hcur2`.
    - `hm0` combines `hcur` and `hfall2` with `lighten` when attached hats are enabled;
      otherwise it uses `hfall2`. It is followed by
      `switch_hats_height - 1` copies of `dilation=coordinates=64` for `up` (each grows
      the caps by one row upwards).
    - `hatmask` = `yuv_mask` of `hm0`; the caps are drawn with
      `[base][hatcolor][hatmask]maskedmerge` over the bars. Hat color is the shared
      gradient at its current height or a cached orange layer.
  - Lines (when enabled): a cached white layer contains black `drawbox` separators at
    `ceil(i * w / cols - 0.5)` for each column. A luma-only darken blend applies it last.
  - The output uses the selected YUV format; there is no trailing `format` filter.
- `showcqt`:
  - `aformat=channel_layouts=stereo`
  - `firequalizer` with gain
    `'1.4884e8 * f*f*f / (f*f + 424.36) / (f*f + 1.4884e8) / sqrt(f*f + 25122.25)'`,
    `scale=linlin`, `wfunc=tukey`, `zero_phase=on`, `fft2=on`
  - `showcqt` with `fps`, `size=wxh`, `count=ceil(w*180/1920/fps)`, `csp=bt709`,
    `bar_g=2`, `sono_g=4`, `bar_v=9`, `sono_v=17`,
    font `'Nimbus Mono L,Courier New,mono|bold'`, `fontcolor='a(0)'`, `tc=0.33`,
    `attack=0.033`, and a `tlength` expression based on `st`/`ld`.
  - `format=yuv420p`
- `avectorscope`: `aformat sample_rates=192000`, `avectorscope size=wxh:r=fps`,
  `format=rgb0`.
- `showspectrum`: `showspectrum size=wxh:win_func=blackman`, output `[vo]`.
- `showcqtbar`:
  - `axis_h = ceil(w * 12 / 1920) * 4`
  - same `firequalizer` stage as `showcqt`
  - `showcqt` with `size=wx((h+axis_h)/2)`, `count=1`, `sono_h=0`, `axis_h=axis_h`,
    same font/color/`tc`/`attack`/`tlength`
  - splits into `[v0]` and `[v1]`; `[v0]` is cropped to `h=(h-axis_h)/2` at `y=0`,
    `[v1]` is `vflip`; `[v0][v1] vstack [vo]`.
- `showwaves`: `showwaves size=wxh:r=fps:mode=p2p`, `format=rgb0`.
- `showvolume`: `showvolume w=w/2:h=h/8:r=10:m=p:t=false:f=0.8:ds=log:dm=1`,
  `format=rgb0`.
- `off`:
  - scans `track-list`; if any video track exists, returns
    `[aid1] asetpts=PTS [ao]; [vid1] setpts=PTS [vo]` (passes video through).
  - otherwise returns audio pass-through plus `color=c=Black:s=wxh` and
    `format=yuv420p`.
- Unknown name -> log error, return `""`.

### 2.7 Visualizer selection

`select_visualizer(vtrack, atrack)`:

- returns `""` if `atrack == nil` or `mode == "off"`.
- `force` -> always return `get_visualizer(...)`.
- `noalbumart` -> visualize only when `vtrack == nil`, else `""`.
- `novideo` -> visualize when `vtrack == nil` or `vtrack.albumart` is true, else `""`.
- unknown mode -> log error, return `""`.

### 2.8 Hook behavior

`visualizer_hook()`:

- bails if `track-list/count` is `<= 0`.
- reads `current-tracks/audio` and `current-tracks/video`.
- if both are nil, iterates `track-list` to pick a video track (unless `vid` is `"no"`)
  and any audio track.
- selects a graph and, when non-empty and different from current `lavfi-complex`,
  sets `file-local-options/lavfi-complex` (prevents endless loop).

Registration:

- `mp.add_hook("on_preloaded", 50, visualizer_hook)`
- `mp.observe_property("current-tracks/audio", "native", visualizer_hook)`
- `mp.observe_property("current-tracks/video", "native", visualizer_hook)`

### 2.9 Cycling

`cycle_visualizer()` finds the current `opts.name` in `visualizer_name_list`, advances
with wraparound, sets `opts.name`, shows `mp.osd_message(string.format(osd_format,
opts.name), osd_time)`, and calls `visualizer_hook()`. Bound with
`mp.add_key_binding(cycle_key, "cycle-visualizer", cycle_visualizer)`.

## 3. firequalizer15.lua

### 3.1 Purpose

Interactive 15-band linear-phase equalizer. Gains are persisted and applied to mpv's
audio filter chain as a `firequalizer` lavfi graph.

### 3.2 State and constants

- `num_entry = 15`, `selected_entry = 0`.
- `min_val = -360`, `max_val = 120`: gain is stored in tenths of a dB, so the UI range
  is -36.0 dB to +12.0 dB.
- `gain_table` keys `eq0`..`eq14`, initial value 0, read from options and clamped to
  `[min_val, max_val]`.
- `stale_gain_entry` tracks the last graph applied to avoid redundant filter inserts.
- `freq_label` maps `eq0`..`eq14` to display labels: 0, 65, 157, 288, 472, 733, 1k1,
  1k6, 2k4, 3k4, 4k9, 7k0, 10k, 14k, 20k Hz. Each label string already contains the
  `"# "` prefix, padding and the `":"` suffix (for example `"#   0 Hz:"`).

### 3.3 Persistence

`save_gain_table()` writes `eqN=<value>` lines for all bands to
`<lua-settings>/<script-name>.conf`, where the folder comes from
`mp.find_config_file("lua-settings")`. Missing folder/file logs a warning and skips
saving.

### 3.4 OSD

Rendered with `mp.set_osd_ass(0, 0, str)` using ASS styling:

- normal color `ffffff`, selected color `00ffff`, font size 70, family `mono`.
- header line `Linear Phase 15-Bands Equalizer`.
- one line per band: label, gain as `%7.1f` dB, then a bar of `=` characters.
- `gain_line(x)` starts at 10 and appends `=` while `x <= gain - min_val`, stepping 20.
- `hide_osd_ass()` sets `"{}"`.

### 3.5 Filter graph

`gen_gain_entry()` builds `entry(index,gain*0.1)` entries joined with `;`.
`insert_filter()` adds an audio filter:

`af add @<script-name>:lavfi=graph=[firequalizer=wfunc=tukey:delay=0.028:scale=linlog:zero_phase=on:gain_entry='...':gain='cubic_interpolate(2.8853900817779269*log(f/157.48+1))']`

`audio_reconfig()` rebuilds the entry string and re-inserts the filter only when it
differs from `stale_gain_entry`. It runs at load and on `playback-restart`.

`send_command()` issues `af-command <script-name> gain_entry <entries>` for live
updates.

### 3.6 Key bindings

Toggle:

- `ctrl+e` -> `toggle_control`

While control is enabled (forced bindings, prefixed with `<script-name>-`):

- `UP` / `DOWN` -> `prev_entry` / `next_entry` (repeatable), move selection within
  `[0, num_entry-1]`, then show OSD.
- `LEFT` / `RIGHT` -> `decrease_gain` / `increase_gain` (repeatable), step by 1
  tenth-dB within `[min_val, max_val]`, send live command, show OSD, save table.
- `[` -> `copy_prev`, `]` -> `copy_next`: copy the neighboring band's gain (clamped at
  the ends), send, show, save.

Disabling removes all six bindings and hides the OSD.

## 4. Readme.md documented modifications

`Readme.md` starts with a timestamp comment block and documents:

- install notes (`visualizer.lua`, `firequalizer15.lua`), key bindings (`c`, `f` and the
  equalizer keys), and tables of all `visualizer.lua` options with defaults.
- the intentional changes to the original `visualizer.lua`:
  - Removed the two `axisfile = data\\:'...':` lines (axis PNG data remains defined but
    unused).
  - Changed `fontcolor` in both places from the frequency/color expression to
    `"fontcolor = 'a(0)':"` (transparent font).
  - Added the `spectrum` visualizer (default), its options, and the on-screen name message
    when cycling.

## 5. Known constraints and caveats

- `~~/lua-settings` (mpv config `lua-settings` folder) must exist for equalizer gains
  to persist.
- Equalizer gains are saved on every gain change; no debounce.
- `visualizer.lua` returns without action when another script already set
  `lavfi-complex`.
- `firequalizer15.lua` inserts its filter at load and on every `playback-restart`; an
  unguarded external `af` change is not detected beyond `stale_gain_entry` comparison.
- `spectrum` needs these filters in mpv's libavfilter: `showfreqs`, `lutyuv`, `geq`,
  `scale`, `null`, `trim`, `loop`, `lagfun`, `blend`, `erosion`, `dilation`, `mergeplanes`,
  `maskedmerge`, `drawbox`.
- The cached constant layers depend on `trim=end_frame=1,loop=loop=-1:size=1` looping a
  one-frame input.
- `switch_lines` and `switch_low_cpu_hats` are ignored (treated as false) when
  both `switch_column_count` and `switch_column_width` are 0.
- With `switch_hats_vscale` above 1, each erosion/dilation step is `vscale` output pixels
  and cap positions move in steps of `vscale` pixels.
- `showfreqs size=` and the other visualizers use `h` unfloored, while the new `spectrum`
  layers use `hi = floor(h)`; with the allowed `quality` and `switch_columns_height` values `h` is an even
  integer, so both agree.
- `cycle_visualizer()`: if `opts.name` is not in `visualizer_name_list`, `index` stays nil
  and `opts.name` becomes nil.
- Compared with the previous `geq` based `spectrum` graph: the cap of the last column now
  follows the real bar (the old graph misplaced it), a few faint falling-cap rows differ by
  about 10 levels, and chroma differs slightly at bar edges.
- `firequalizer15.lua` has no timestamp header (`rules.md` asks for one when it is modified).
- Performance, measured 2026-11-10 in a sandbox (ffmpeg 6.1.1, single thread, filter graph
  only, 10 s of synthetic audio, `medium`, 15 fps, column width 16), CPU-seconds, previous
  older graph -> graph measured at that time: hats off 1.07 -> 0.49; hats on 4.6 -> 0.89; hats on with lines
  6.1 -> 0.95; hats on with `switch_low_cpu_hats` false 21.2 -> 2.46. For comparison
  `showcqtbar` 0.18 and `showcqt` 0.30. CPU reported in mpv by the user: hats on about 32%
  -> 15%, hats off about 37-40% -> 10% (`showcqtbar` about 8-9%).
